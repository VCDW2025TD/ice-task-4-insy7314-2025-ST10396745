export default function HomePage() {
  return (
    <div>
      <h1>Home</h1>
      <p>Welcome. Use the nav to register or log in.</p>
    </div>
  );
}
